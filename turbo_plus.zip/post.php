<?php

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>बधाई हो! आपका आदेश स्वीकार कर लिया गया है!</title>

</head>

<body cz-shortcut-listen="true"><img height="1" width="1" src="https://www.facebook.com/tr?id=769506657875392&amp;ev=Contact&amp;noscript=1">



    <br>
    <center>

        <div class="wrap_block_success">
            <div class="block_success">
                <h2>बधाई हो! आपका आदेश स्वीकार कर लिया गया है!</h2><br>
                <p class="success">आदेश की पुष्टि के लिए ऑपरेटर आपसे शीघ्र ही संपर्क करेगा। अपना संपर्क नंबर दें।</p>
                <br>
                <h1 style="color:#FF0000; text-align: center;">हमें चुनने के लिए धन्यवाद!</h1>
            </div>
        </div>
    </center>
    <style>
        html,
        body,
        div,
        span,
        applet,
        object,
        iframe,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        p,
        blockquote,
        pre,
        a,
        abbr,
        acronym,
        address,
        big,
        cite,
        code,
        del,
        dfn,
        em,
        img,
        ins,
        kbd,
        q,
        s,
        samp,
        small,
        strike,
        strong,
        sub,
        sup,
        tt,
        var,
        b,
        u,
        i,
        center,
        dl,
        dt,
        dd,
        ol,
        ul,
        li,
        fieldset,
        form,
        label,
        legend,
        table,
        caption,
        tbody,
        tfoot,
        thead,
        tr,
        th,
        td,
        article,
        aside,
        canvas,
        details,
        embed,
        figure,
        figcaption,
        footer,
        header,
        hgroup,
        menu,
        nav,
        output,
        ruby,
        summary,
        time,
        mark,
        audio,
        video {
            margin: 0;
            padding: 0;
            border: 0;
            font: inherit;
            font-size: 100%;
            vertical-align: baseline;
        }

        /* HTML5 display-role reset for older browsers */
        article,
        aside,
        details,
        figcaption,
        figure,
        footer,
        header,
        hgroup,
        menu,
        nav,
        section {
            display: block;
        }

        body {
            line-height: 1;
            height: 100%;
            font-family: Arial;
            font-size: 15px;
            color: #313e47;
        }

        html {
            height: 100%;
        }

        ol,
        ul {
            list-style: none;
        }

        h2 {
            font-size: 36px;
            line-height: 44px;
            color: #313e47;
            text-align: center;
            text-transform: uppercase;
            font-weight: bold;
        }

        a {
            color: #69B9FF;
        }

        a:hover {
            color: #e14740;
        }

        .wrap_block_success {
            width: 100%;
            height: 100%;
        }

        .order_number {
            text-align: center;
            font-family: Arial;
            font-size: 30px;
            text-transform: uppercase;
            color: #424242;
            line-height: 38px;
            margin: 25px 0 25px 0;
        }

        .order_number span {
            color: #e14740;
        }

        .url_more_info {
            text-align: center;
            font-size: 20px;
            display: block;
            margin: 20px 0px;
        }

        .url_more_info:hover {
            color: #e14740;
        }

        .block_success {
            max-width: 960px;
            padding: 70px 30px 0 30px;
            margin: 0px auto;
        }

        .success {
            text-align: center;
        }

        @media (max-width:750px) {
            h2 {
                font-size: 24px;
            }

            .order_number {

                font-size: 20px;

            }

        }
    </style>

</body>

</html>